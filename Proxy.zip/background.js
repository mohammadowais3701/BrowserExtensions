var config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "128.199.51.79",
        port: parseInt(22225)	
      },
      bypassList: ["foobar.com"]
    }
  };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {

   debugger;
    return {
        authCredentials: {
            username: "lum-customer-ticket_finder-zone-distrib-country-us-session-VuG8Hwefn2",
            password: "77f7bJ9a16e0"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
);