chrome.tabs.onActivated.addListener(function(activeInfo) {
   // window.location.reload();
   
  chrome.cookies.getAll({}, (cookies)=>{
  
  for (let index = 0; index < cookies.length; index++) {
   // alert("length=--"+cookies[0].domain)
    let url=("https://www."+((cookies[index].domain).replace('www.',''))).replace('..','.');
    // alert(url);
    // alert(cookies[index].name);
   chrome.cookies.remove({"url": url, "name": cookies[index].name}, function(deleted_cookie) { //alert(JSON.stringify(deleted_cookie)); 
    var request = {
           
    //    message: JSON.stringify(obj['cookie']),
   
        domain: cookies[index].domain,
      
        name:cookies[index].name,
        value:cookies[index].value,
        expires:  cookies[index].expirationDate
    
            };
         //   chrome.tabs.sendMessage(tabs[0].id,msg);
    var cookieBody = request.name+"="+request.value+"; domain="+request.domain+"; path=/; expires="+request.expires+"; secure;";
    // console.log(request.tabID+"--Message Background-> "+cookieBody);
    // localStorage.setItem(activeInfo.tabId+","+request.domain+","+request.name,cookieBody);



});
    
  }
  
  
  })
 
  if(localStorage.length > 0)
  {
      for (let i = 0; i < localStorage.length; i++) {

          var element = localStorage.key(i);
     console.log(activeInfo.tabId+"___"+element.includes(activeInfo.tabId));
          if(element.includes(activeInfo.tabId)){
          myCookie = localStorage.getItem(element);
        //  alert(myCookie);
          var msg = {
     
            message:"CookieSet",
            tabId:activeInfo.tabId,
            cooki:myCookie 
            };
            chrome.tabs.sendMessage(activeInfo.tabId,msg);

          }
          
      }
      //location.reload(true);
  }

      
          
    ////////////////////////////////////////////        
        //       chrome.cookies.onChanged.addListener(function(ta) {
        //          obj=JSON.parse(JSON.stringify(ta))
        //        console.log("Active Info==>"+obj['cookie']['domain']);
        //         obj['cookie']['expirationDate']= (new Date(obj['cookie']['expirationDate']  *1000)).toGMTString();
      
        //        var request = {
           
        //     message: JSON.stringify(obj['cookie']),
       
        //     domain: obj['cookie']['domain'],
          
        //     name: obj['cookie']['name'],
        //     value:obj['cookie']['value'],
        //     expires:    obj['cookie']['expirationDate']
        //         };
        //      //   chrome.tabs.sendMessage(tabs[0].id,msg);
        // var cookieBody = request.name+"="+request.value+"; domain="+request.domain+"; path=/; expires="+request.expires+"; secure;";
        //  console.log(request.tabID+"--Message Background-> "+cookieBody);
        //  localStorage.setItem(request.tabID+","+request.domain+","+request.name,cookieBody);
        //         console.log(activeInfo.tabId);
              
        //       })
           

////////////////////////////////////////////////



      // })
  
  
  
  })

  chrome.tabs.onUpdated.addListener(function( tabId, {},  tab) {

    chrome.cookies.getAll({}, (cookies)=>{
  
        for (let index = 0; index < cookies.length; index++) {
         // alert("length=--"+cookies[0].domain)
          let url=("https://www."+((cookies[index].domain).replace('www.',''))).replace('..','.');
          // alert(url);
          // alert(cookies[index].name);
        //  chrome.cookies.remove({"url": url, "name": cookies[index].name}, function(deleted_cookie) { 
        // });
        
        //alert(JSON.stringify(deleted_cookie)); 
          var request = {
                 
          //    message: JSON.stringify(obj['cookie']),
         
              domain: cookies[index].domain,
            
              name:cookies[index].name,
              value:cookies[index].value,
              expires:  cookies[index].expirationDate
          
                  };
               //   chrome.tabs.sendMessage(tabs[0].id,msg);
          var cookieBody = request.name+"="+request.value+"; domain="+request.domain+"; path=/; expires="+request.expires+"; secure;";
          // console.log(tabId+"--Message Background-> "+cookieBody);
           localStorage.setItem(tabId+","+request.domain+","+request.name,cookieBody);
      
      
      
    
          
        }
       
        
        })
       
  })
