chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    
    document.cookie = request.cooki;
  
    console.log(request.cooki);
 })
