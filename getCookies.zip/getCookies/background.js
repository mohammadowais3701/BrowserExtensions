chrome.cookies.onChanged.addListener(function() {
   // alert(JSON.stringify(changeInfo.cookie))

    chrome.cookies.getAll({url:"https://www.linkedin.com/"}, function(cookies){
       // alert(cookies.length);
       var cook="";
      for(var i=0;i<cookies.length;i++){
          cook = cook + JSON.stringify(cookies[i]);
         chrome.cookies.remove({url:"https://www.linkedin.com/",name:cookies[i].name});
      }

    //   alert(cookies.length)
    //   alert(cook);
    })
   
var details = {
    "name":"abc",
    "url":"https://www.linkedin.com/",
    "value":"123",
    "domain":"abcd.com",
    "path":"http",
    "secure":true,
    "httpOnly":true


};
setTimeout(function(){ 
    chrome.cookies.set({
        "name": "Sample1",
        "url": "https://www.linkedin.com/",
        "value": "Dummy Data"
    });
       
},20);  
 

    
  });