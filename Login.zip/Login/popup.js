
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('log');
    var name;
    var password;
    
    checkPageButton.addEventListener('click', function() {
        localStorage.setItem("login","0");
        name=document.getElementById('Uname').value;
        password=document.getElementById('Pass').value;
     if(name=="test" && password=="test"){
        localStorage.setItem("login","1")
    }
       else{
        
        alert("Wrong User Name Password");

       } 
    //   chrome.tabs.getSelected(null, function(tab) {
    //     alert("Hello..! It's my first chrome extension.");
    //   });
    }, false);
  }, false);