// Future JavaScript will go here
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('log');
    var name;
    var password;
    checkPageButton.addEventListener('click', function(tab) {
        email=document.getElementById('email').value;
        password=document.getElementById('password').value;
     if(email=="test@gmail.com" && password=="test"){
       
            localStorage.setItem("login","1");
            
        
        }
       else{
           
        alert("Wrong User email Password");

       } 
    //   chrome.tabs.getSelected(null, function(tab) {
    //     alert("Hello..! It's my first chrome extension.");
    //   });
    }, false);
  }, false);